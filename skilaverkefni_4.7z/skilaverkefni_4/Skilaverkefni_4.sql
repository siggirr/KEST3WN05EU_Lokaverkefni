-- C# Útgáfan
-- Create
CREATE PROC nyr_nemandi
@sudentID int
@firstName varchar(55),
@lastName varchar(55),
@dob date
BEGIN
	INSERT INTO Student
	(
	firstName,
	lastName,
	dob
	)
	VALUES
	(
	@firstName
	@lastName
	@dob
	)
END

-- Update
CREATE PROC breyta_nemanda
@sudentID int
@firstName varchar(55),
@lastName varchar(55),
@dob date
BEGIN
	UPDATE Student
	SET
	firstName = @firstName,
	lastName = @lastName,
	dob = @dob
	WHERE studentID = @studentID
END

-- View
CREATE PROC nemandi
@SearchText varchar(50)
AS BEGIN
SELECT *
FROM Student
WHERE @SearchText='' OR
	NAME LIKE '%'+@SearchText+'%'
END

-- Delete
CREATE PROC eyda_nemanda
@ContactID int
AS BEGIN
DELETE FROM Student
WHERE studentID = @studentID
END

--mysql úgáfan
-- CREATE
DELIMITER //
DROP PROCEDURE IF EXISTS `nyr_nemandi` //
CREATE PROCEDURE `nyr_nemandi`()
BEGIN
	DECLARE pr_firstName varchar(55);
	DECLARE pr_lastName varchar(55);
	DECLARE pr_dob date;
	
		INSERT INTO Student
	(
	firstName,
	lastName,
	dob
	)
	VALUES
	(
	pr_firstName
	pr_lastName
	pr_dob
	)
END //
DELIMITER;
	
CALL `nyr_nemandi`();

-- UPDATE
DELIMITER //
DROP PROCEDURE IF EXISTS `breyta_nemanda` //
CREATE PROCEDURE `breyta_nemanda`(pr_studentID INT)
BEGIN
	DECLARE pr_firstName varchar(55);
	DECLARE pr_lastName varchar(55);
	DECLARE pr_dob date;
	
	UPDATE Student
	SET
	firstName = pr_firstName,
	lastName = pr_lastName,
	dob = pr_dob
	WHERE studentID = pr_studentID
	VALUES
	(
	pr_firstName
	pr_lastName
	pr_dob
	)
END //
DELIMITER;
	
CALL `breyta_nemanda`();

-- EÐA TEKUR ALLAR FÆRIBREYTUR
-- UPDATEVERSION2

DELIMITER //
DROP PROCEDURE IF EXISTS `breyta_nemanda` //
CREATE PROCEDURE `breyta_nemanda`(pr_studentID INT, pr_firstName varchar(55), pr_lastName varchar(55), pr_dob date )
BEGIN
	UPDATE Student
	SET
	firstName = pr_firstName,
	lastName = pr_lastName,
	dob = pr_dob
	WHERE studentID = pr_studentID
	VALUES
	(
	pr_firstName
	pr_lastName
	pr_dob
	)
END //
DELIMITER;
	
CALL `breyta_nemanda`();

-- VIEW//SELECT

DELIMITER //
DROP PROCEDURE IF EXISTS `nemandi` //
CREATE PROCEDURE `nemandi`(pr_SearchText varchar(50))
AS BEGIN
SELECT *
FROM Student
WHERE pr_SearchText='' OR
	NAME LIKE '%'+pr_SearchText+'%'
END //
DELIMITER;


-- DELETE
DELIMITER //
DROP PROCEDURE IF EXISTS `eyda_nemanda` //
CREATE PROCEDURE `eyda_nemanda`(pr_studentID int)
AS BEGIN
DELETE FROM Student
WHERE studentID = pr_studentID
END
END //
DELIMITER;
